
export interface CoordinatePoint {
  distance: number;
  angle: number;
  latitude: number;
  longitude: number;
}
